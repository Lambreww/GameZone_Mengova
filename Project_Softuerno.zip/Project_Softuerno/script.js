// Cleaned script.js for GameZone
// Provides: page navigation, product rendering, search, cart, wishlist, simple login/register with localStorage.

class GameZoneApp {
    constructor() {
        this.products = this._buildProducts();
        this.users = JSON.parse(localStorage.getItem('gz_users') || '[]');
        this.currentUser = JSON.parse(localStorage.getItem('gz_currentUser') || 'null');
        this.cart = JSON.parse(localStorage.getItem('gz_cart') || '[]');
        this.wishlist = JSON.parse(localStorage.getItem('gz_wishlist') || '[]');

        this.init();
    }

    init() {
        document.addEventListener('DOMContentLoaded', () => {
            this.cacheDOM();
            this.bindEvents();
            this.renderAllProductGrids();
            this.updateCartCount();
            this.updateWishlistCount();
            this.updateUserUI();
            this.hideAllSearchResults();
        });
    }

    cacheDOM() {
        this.pages = Array.from(document.querySelectorAll('.page-content'));
        this.searchInput = document.getElementById('searchInput');
        this.searchResultsEl = document.getElementById('searchResults');
        this.logoutBtn = document.getElementById('logoutBtn');
        this.cartCountEl = document.querySelector('.cart-count');
        this.wishlistCountEl = document.querySelector('.wishlist-count');
        this.accountInfoEl = document.getElementById('accountInfo');
        this.wishlistItemsEl = document.getElementById('wishlistItems');
        this.loginModal = document.getElementById('loginModal');
        this.loginForm = document.getElementById('loginForm');
        this.registerForm = document.getElementById('registerForm');
    }

    bindEvents() {
        // Search input: use input event
        if (this.searchInput) {
            this.searchInput.addEventListener('input', (e) => this.handleSearch(e.target.value));
        }

        // Click outside search to hide
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-bar')) {
                this.hideAllSearchResults();
            }
        });

        // Login / register forms
        if (this.loginForm) {
            this.loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const email = document.getElementById('loginEmail').value.trim();
                const password = document.getElementById('loginPassword').value;
                this.login(email, password);
            });
        }
        if (this.registerForm) {
            this.registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const name = document.getElementById('registerName').value.trim();
                const email = document.getElementById('registerEmail').value.trim();
                const password = document.getElementById('registerPassword').value;
                const confirm = document.getElementById('registerConfirmPassword').value;
                this.register(name, email, password, confirm);
            });
        }

        // Close modal when clicking outside modal content
        if (this.loginModal) {
            this.loginModal.addEventListener('click', (e) => {
                if (e.target === this.loginModal) this.closeLoginModal();
            });
        }

        // Logout button
        if (this.logoutBtn) {
            this.logoutBtn.addEventListener('click', () => this.logout());
        }

        // Checkout button
        document.querySelector('.checkout-btn')?.addEventListener('click', () => this.checkout());
    }

    _buildProducts() {
        return [
            // Consoles
            { id:1, name:"Sony PlayStation 5", price:499.99, category:"consoles", image:"https://images.unsplash.com/photo-1606813907291-d86efa9b94db?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["ps5","console","sony","playstation"] },
            { id:2, name:"Xbox Series X", price:499.00, category:"consoles", image:"https://images.unsplash.com/photo-1621259182978-fbf83265f8c0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["xbox","console","microsoft"] },
            { id:3, name:"Nintendo Switch OLED", price:349.99, category:"consoles", image:"https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["switch","nintendo"] },
            { id:4, name:"PlayStation 4 Pro", price:299.99, category:"consoles", image:"https://images.unsplash.com/photo-1593305841991-05c297ba4575?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["ps4","console","sony"] },
            { id:5, name:"Xbox Series S", price:299.00, category:"consoles", image:"https://images.unsplash.com/photo-1637858868790-950aae967e98?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["xbox","console","microsoft"] },
            { id:6, name:"Nintendo Switch Lite", price:199.99, category:"consoles", image:"https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["switch","nintendo"] },

            // Games
            { id:7, name:"Call of Duty: Modern Warfare III", price:69.99, category:"games", image:"https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["cod","fps","action","shooter"] },
            { id:8, name:"The Legend of Zelda: Tears of the Kingdom", price:59.99, category:"games", image:"https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["zelda","adventure","nintendo"] },
            { id:9, name:"Spider-Man 2", price:69.99, category:"games", image:"https://images.unsplash.com/photo-1598550476439-6847785e9e3a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["spiderman","action","adventure"] },
            { id:10, name:"FIFA 24", price:59.99, category:"games", image:"https://images.unsplash.com/photo-1533237264983-4d38e0eec5f9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["fifa","sports","football"] },
            { id:11, name:"Cyberpunk 2077: Phantom Liberty", price:49.99, category:"games", image:"https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["cyberpunk","rpg","action"] },
            { id:12, name:"Super Mario Odyssey", price:49.99, category:"games", image:"https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["mario","platform","nintendo"] },

            // Accessories
            { id:13, name:"DualSense Wireless Controller", price:69.99, category:"accessories", image:"https://images.unsplash.com/photo-1612621344640-5f2b9b0f6a1b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["controller","ps5","wireless"] },
            { id:14, name:"Xbox Wireless Controller", price:59.99, category:"accessories", image:"https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["controller","xbox","wireless"] },
            { id:15, name:"Gaming Headset Pro", price:129.99, category:"accessories", image:"https://images.unsplash.com/photo-1580157788846-0b4b4b4d6f6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["headset","audio","gaming"] },
            { id:16, name:"Charging Dock Station", price:39.99, category:"accessories", image:"https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["dock","charging","station"] },
            { id:17, name:"Gaming Keyboard RGB", price:89.99, category:"accessories", image:"https://images.unsplash.com/photo-1541140532154-b024d705b90a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["keyboard","rgb","gaming"] },
            { id:18, name:"Wireless Gaming Mouse", price:79.99, category:"accessories", image:"https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["mouse","wireless","gaming"] },

            // PC Gaming
            { id:19, name:"Gaming PC RTX 4080", price:2499.00, category:"pc", image:"https://images.unsplash.com/photo-1587202372775-1c6f1a3b6c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["pc","rtx","desktop","gaming"] },
            { id:20, name:"Gaming Laptop RTX 4070", price:1799.00, category:"pc", image:"https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["laptop","gaming","rtx"] },
            { id:21, name:"Gaming Monitor 27\" 144Hz", price:349.99, category:"pc", image:"https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["monitor","gaming","144hz"] },
            { id:22, name:"Mechanical Keyboard", price:129.99, category:"pc", image:"https://images.unsplash.com/photo-1541140532154-b024d705b90a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["keyboard","mechanical","rgb"] },
            { id:23, name:"Gaming Chair Pro", price:299.99, category:"pc", image:"https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["chair","gaming","ergonomic"] },
            { id:24, name:"PC Gaming Bundle", price:1599.99, category:"pc", image:"https://images.unsplash.com/photo-1587202372634-32705e3bf49c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["bundle","pc","gaming"] },

            // Deals
            { id:25, name:"Holiday Console Bundle", price:399.99, category:"deals", image:"https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["bundle","deal","holiday"] },
            { id:26, name:"Game Collection Pack", price:79.99, category:"deals", image:"https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["bundle","games","deal"] },
            { id:27, name:"Accessory Starter Kit", price:149.99, category:"deals", image:"https://images.unsplash.com/photo-1612621344640-5f2b9b0f6a1b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["kit","accessories","deal"] },
            { id:28, name:"PC Gaming Special", price:1999.99, category:"deals", image:"https://images.unsplash.com/photo-1587202372775-1c6f1a3b6c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["pc","deal","special"] },
            { id:29, name:"Limited Time Offer", price:29.99, category:"deals", image:"https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["deal","limited","offer"] },
            { id:30, name:"Black Friday Bundle", price:299.99, category:"deals", image:"https://images.unsplash.com/photo-1542744095-291d1f67b221?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80", tags:["bundle","blackfriday","deal"] }
        ];
    }

    // --- Page navigation ---
    showPage(pageId) {
        this.pages.forEach(p => p.classList.remove('active-page'));
        const target = document.getElementById(pageId);
        if (target) {
            target.classList.add('active-page');
            window.scrollTo({top:0, behavior:'smooth'});
            
            // Re-render products when switching to category pages
            if (['home', 'consoles', 'games', 'accessories', 'pc', 'deals'].includes(pageId)) {
                this.renderAllProductGrids();
            }
            
            // Render cart when switching to cart page
            if (pageId === 'cart') {
                this.renderCart();
            }
            
            // Update account info when switching to account page
            if (pageId === 'account') {
                this.updateUserUI();
            }
            
            // Render wishlist when switching to wishlist page
            if (pageId === 'wishlist') {
                this.renderWishlist();
            }
        }
        // hide login if open
        this.closeLoginModal();
    }

    // --- Products rendering ---
    renderAllProductGrids() {
        const grids = document.querySelectorAll('.product-grid');
        grids.forEach(grid => {
            // find which page this grid belongs to by traversing up to parent with id
            let parent = grid.parentElement;
            while (parent && !parent.id) parent = parent.parentElement;
            const pageId = parent ? parent.id : null;
            if (pageId) {
                this.renderProductsForCategory(pageId, grid);
            }
        });
    }

    renderProductsForCategory(category, gridEl) {
        // clear
        gridEl.innerHTML = '';
        let products = [];
        
        if (category === 'home') {
            // Show 8 random featured products on home page
            products = this.getRandomProducts(8);
        } else {
            // Show all products from the specific category
            products = this.products.filter(p => p.category === category);
        }
        
        if (products.length === 0) {
            gridEl.innerHTML = '<p>No products in this category.</p>';
            return;
        }
        
        products.forEach(p => {
            const div = document.createElement('div');
            div.className = 'product-card';
            const isInWishlist = this.wishlist.some(item => item.productId === p.id);
            
            div.innerHTML = `
                <div class="product-image-container">
                    <img src="${p.image}" alt="${p.name}" onerror="this.src='https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80'">
                    <button class="wishlist-btn ${isInWishlist ? 'in-wishlist' : ''}" onclick="app.toggleWishlist(${p.id})">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
                <div class="product-info">
                    <h3 class="product-name">${p.name}</h3>
                    <p class="product-price">$${p.price.toFixed(2)}</p>
                    <button class="cta-button add-to-cart" data-id="${p.id}">Add to Cart</button>
                </div>
            `;
            gridEl.appendChild(div);

            div.querySelector('.add-to-cart').addEventListener('click', () => {
                this.addToCart(p.id);
            });
        });
    }

    getRandomProducts(count) {
        const shuffled = [...this.products].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, count);
    }

    // --- Wishlist ---
    toggleWishlist(productId) {
        if (!this.currentUser) {
            alert('Please login to add items to wishlist.');
            this.openLoginModal();
            return;
        }

        const product = this.products.find(p => p.id === productId);
        const existingIndex = this.wishlist.findIndex(item => item.productId === productId);
        
        if (existingIndex > -1) {
            // Remove from wishlist
            this.wishlist.splice(existingIndex, 1);
            this.showNotification('Removed from wishlist: ' + product.name);
        } else {
            // Add to wishlist
            this.wishlist.push({ 
                productId, 
                name: product.name, 
                price: product.price, 
                image: product.image,
                category: product.category
            });
            this.showNotification('Added to wishlist: ' + product.name);
        }
        
        localStorage.setItem('gz_wishlist', JSON.stringify(this.wishlist));
        this.updateWishlistCount();
        this.renderAllProductGrids(); // Update wishlist buttons
    }

    updateWishlistCount() {
        const total = this.wishlist.length;
        if (this.wishlistCountEl) this.wishlistCountEl.textContent = total;
    }

    renderWishlist() {
        if (!this.wishlistItemsEl) return;
        
        if (this.wishlist.length === 0) {
            this.wishlistItemsEl.innerHTML = `
                <div class="empty-cart-message">
                    <p>Your wishlist is empty</p>
                    <a class="cta-button" onclick="showPage('home')">Start Shopping</a>
                </div>
            `;
            return;
        }
        
        let html = '';
        
        this.wishlist.forEach(item => {
            const product = this.products.find(p => p.id === item.productId);
            if (product) {
                html += `
                    <div class="wishlist-item">
                        <div class="wishlist-item-image">
                            <img src="${item.image}" alt="${item.name}" onerror="this.src='https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80'">
                        </div>
                        <div class="wishlist-item-details">
                            <div class="wishlist-item-title">${item.name}</div>
                            <div class="wishlist-item-price">$${item.price.toFixed(2)}</div>
                            <div class="wishlist-item-category">${item.category}</div>
                        </div>
                        <div class="wishlist-item-actions">
                            <button class="cta-button" onclick="app.addToCart(${item.productId})">Add to Cart</button>
                            <button class="remove-wishlist-item" onclick="app.toggleWishlist(${item.productId})">
                                <i class="fas fa-trash"></i> Remove
                            </button>
                        </div>
                    </div>
                `;
            }
        });
        
        this.wishlistItemsEl.innerHTML = html;
    }

    // --- Search ---
    handleSearch(query) {
        const q = String(query || '').trim().toLowerCase();
        if (!q || q.length < 2) {
            this.hideAllSearchResults();
            return;
        }
        const results = this.products.filter(p => {
            return p.name.toLowerCase().includes(q) || 
                   p.tags.join(' ').toLowerCase().includes(q) || 
                   p.category.toLowerCase().includes(q);
        });
        this.displaySearchResults(results);
    }

    displaySearchResults(results) {
        if (!this.searchResultsEl) return;
        
        if (results.length > 0) {
            this.searchResultsEl.style.display = 'block';
        } else {
            this.searchResultsEl.style.display = 'none';
        }
        
        this.searchResultsEl.innerHTML = '';
        if (results.length === 0) {
            const no = document.createElement('div');
            no.className = 'search-result-item';
            no.textContent = 'No products found';
            this.searchResultsEl.appendChild(no);
            return;
        }
        results.slice(0,5).forEach(p => {
            const item = document.createElement('div');
            item.className = 'search-result-item';
            item.innerHTML = `
                <img src="${p.image}" alt="${p.name}" onerror="this.src='https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80'">
                <div class="search-result-info">
                    <div class="search-result-name">${p.name}</div>
                    <div class="search-result-price">$${p.price.toFixed(2)}</div>
                </div>
                <span class="search-result-category">${p.category}</span>
            `;
            item.addEventListener('click', () => {
                // go to category page and highlight
                this.showPage(p.category);
                this.hideAllSearchResults();
                this.searchInput.value = '';
            });
            this.searchResultsEl.appendChild(item);
        });
    }

    hideAllSearchResults() {
        if (this.searchResultsEl) {
            this.searchResultsEl.innerHTML = '';
            this.searchResultsEl.style.display = 'none';
        }
    }

    // --- Cart ---
    addToCart(productId) {
        const p = this.products.find(x => x.id === productId);
        if (!p) return;
        const existing = this.cart.find(i => i.productId === productId);
        if (existing) existing.quantity += 1;
        else this.cart.push({ productId, quantity:1, name: p.name, price: p.price, image: p.image });
        localStorage.setItem('gz_cart', JSON.stringify(this.cart));
        this.updateCartCount();
        
        // Show notification
        this.showNotification('Added to cart: ' + p.name);
    }

    updateCartCount() {
        const total = this.cart.reduce((s,i) => s + i.quantity, 0);
        if (this.cartCountEl) this.cartCountEl.textContent = total;
    }

    renderCart() {
        const cartItemsEl = document.querySelector('.cart-items');
        if (!cartItemsEl) return;
        
        if (this.cart.length === 0) {
            cartItemsEl.innerHTML = `
                <div class="empty-cart-message">
                    <p>Your cart is empty</p>
                    <a class="cta-button" onclick="showPage('home')">Continue Shopping</a>
                </div>
            `;
            return;
        }
        
        let html = '';
        let subtotal = 0;
        
        this.cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            html += `
                <div class="cart-item">
                    <div class="cart-item-image">
                        <img src="${item.image}" alt="${item.name}" onerror="this.src='https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80'">
                    </div>
                    <div class="cart-item-details">
                        <div class="cart-item-title">${item.name}</div>
                        <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                        <div class="cart-item-actions">
                            <div class="quantity-control">
                                <button class="quantity-btn" onclick="app.updateQuantity(${item.productId}, -1)">-</button>
                                <input type="number" class="quantity-input" value="${item.quantity}" min="1" readonly>
                                <button class="quantity-btn" onclick="app.updateQuantity(${item.productId}, 1)">+</button>
                            </div>
                            <button class="remove-item" onclick="app.removeFromCart(${item.productId})">Remove</button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        cartItemsEl.innerHTML = html;
        
        // Update summary
        const shipping = subtotal > 0 ? 9.99 : 0;
        const total = subtotal + shipping;
        
        document.querySelector('.subtotal').textContent = `$${subtotal.toFixed(2)}`;
        document.querySelector('.shipping').textContent = `$${shipping.toFixed(2)}`;
        document.querySelector('.total').textContent = `$${total.toFixed(2)}`;
    }

    updateQuantity(productId, change) {
        const item = this.cart.find(i => i.productId === productId);
        if (item) {
            item.quantity += change;
            if (item.quantity < 1) item.quantity = 1;
            localStorage.setItem('gz_cart', JSON.stringify(this.cart));
            this.renderCart();
            this.updateCartCount();
        }
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(i => i.productId !== productId);
        localStorage.setItem('gz_cart', JSON.stringify(this.cart));
        this.renderCart();
        this.updateCartCount();
    }

    checkout() {
        if (!this.currentUser) {
            alert('Please login to checkout.');
            this.openLoginModal();
            return;
        }
        if (this.cart.length === 0) {
            alert('Your cart is empty.');
            return;
        }
        // simple checkout simulation
        const subtotal = this.cart.reduce((s,i) => s + i.price * i.quantity, 0);
        const shipping = 9.99;
        const total = subtotal + shipping;
        
        alert(`Order placed successfully!\n\nSubtotal: $${subtotal.toFixed(2)}\nShipping: $${shipping.toFixed(2)}\nTotal: $${total.toFixed(2)}`);
        
        // save as order to user
        const userIndex = this.users.findIndex(u => u.email === this.currentUser.email);
        if (userIndex !== -1) {
            this.users[userIndex].orders = this.users[userIndex].orders || [];
            this.users[userIndex].orders.push({ 
                id: Date.now(), 
                date: new Date().toISOString().slice(0,10), 
                total, 
                items: [...this.cart] 
            });
            localStorage.setItem('gz_users', JSON.stringify(this.users));
        }
        this.cart = [];
        localStorage.setItem('gz_cart', JSON.stringify(this.cart));
        this.updateCartCount();
        this.renderCart();
    }

    showNotification(message) {
        // Remove existing notification
        const existingNotification = document.querySelector('.add-to-cart-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        const notification = document.createElement('div');
        notification.className = 'add-to-cart-notification';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    // --- Login/Register ---
    openLoginModal() {
        if (this.loginModal) this.loginModal.style.display = 'block';
    }
    
    closeLoginModal() {
        if (this.loginModal) this.loginModal.style.display = 'none';
    }

    register(name, email, password, confirm) {
        if (!name || !email || !password) { alert('Please fill all registration fields.'); return; }
        if (password !== confirm) { alert('Passwords do not match.'); return; }
        if (this.users.find(u => u.email === email)) { alert('User already exists.'); return; }
        const user = { id: Date.now(), name, email, password, orders: [] };
        this.users.push(user);
        localStorage.setItem('gz_users', JSON.stringify(this.users));
        alert('Registration successful. You can now login.');
        this.closeLoginModal();
    }

    login(email, password) {
        const user = this.users.find(u => u.email === email && u.password === password);
        if (!user) { alert('Invalid credentials.'); return; }
        this.currentUser = { id: user.id, name: user.name, email: user.email };
        localStorage.setItem('gz_currentUser', JSON.stringify(this.currentUser));
        this.updateUserUI();
        this.closeLoginModal();
        alert('Logged in as ' + user.name);
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('gz_currentUser');
        this.updateUserUI();
        alert('Logged out.');
    }

    updateUserUI() {
        // show/hide logout button and update account info
        if (this.logoutBtn) this.logoutBtn.style.display = this.currentUser ? 'inline-block' : 'none';
        if (this.accountInfoEl) {
            if (this.currentUser) {
                const user = this.users.find(u => u.email === this.currentUser.email);
                let ordersHtml = '';
                
                if (user && user.orders && user.orders.length > 0) {
                    ordersHtml = user.orders.map(o => `
                        <div class="order">
                            <p><strong>Order #${o.id}</strong> — ${o.date} — $${o.total.toFixed(2)}</p>
                            <div class="order-items">
                                ${o.items.map(item => `
                                    <div class="order-item">
                                        ${item.name} x${item.quantity} - $${(item.price * item.quantity).toFixed(2)}
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `).join('');
                } else {
                    ordersHtml = '<p>No orders yet.</p>';
                }
                
                this.accountInfoEl.innerHTML = `
                    <div class="account-info">
                        <h3>Welcome, ${this.currentUser.name}!</h3>
                        <p><strong>Email:</strong> ${this.currentUser.email}</p>
                        <div class="account-orders">
                            <h4>Order History</h4>
                            ${ordersHtml}
                        </div>
                    </div>
                `;
            } else {
                this.accountInfoEl.innerHTML = `
                    <div class="account-info">
                        <p>Please login or register to view account details.</p>
                        <button class="cta-button" onclick="openLoginModal()">Login / Register</button>
                    </div>
                `;
            }
        }
    }
}

// Global helpers for HTML to call
let _app = null;

function showPage(id) { if (_app) _app.showPage(id); }
function openLoginModal() { if (_app) _app.openLoginModal(); }
function closeLoginModal() { if (_app) _app.closeLoginModal(); }
function logout() { if (_app) _app.logout(); }
function checkout() { if (_app) _app.checkout(); }

function handleSearch(e) {
    if (_app) {
        if (typeof e === 'string') _app.handleSearch(e);
        else if (e && e.target) _app.handleSearch(e.target.value);
    }
}

function handleAccountClick(e) {
    e.preventDefault();
    if (_app && _app.currentUser) {
        showPage('account');
    } else {
        openLoginModal();
    }
}

function openTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show the specific tab content
    document.getElementById(tabName).classList.add('active');
    
    // Activate the clicked tab button
    event.currentTarget.classList.add('active');
}

// Initialize
_app = new GameZoneApp();
window.app = _app;